// PATH: src/app/api/auth/register/route.ts
import { prisma }       from '@/lib/prisma'
import { NextResponse } from 'next/server'
import bcrypt           from 'bcryptjs'

export async function POST(req: Request) {
  const { name, email, password } = await req.json()

  if (!name || !email || !password) {
    return NextResponse.json({ error: 'All fields are required.' }, { status: 400 })
  }
  if (password.length < 8) {
    return NextResponse.json({ error: 'Password must be at least 8 characters.' }, { status: 400 })
  }

  const existing = await prisma.user.findUnique({ where: { email } })
  if (existing) {
    return NextResponse.json({ error: 'An account with this email already exists.' }, { status: 409 })
  }

  const hashed = await bcrypt.hash(password, 12)

  await prisma.user.create({
    data: {
      name,
      email,
      password:      hashed,
      emailVerified: new Date(), // auto-verify — no email step
    },
  })

  return NextResponse.json({ success: true })
}